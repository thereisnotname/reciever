# @babel/helper-remap-async-to-generator

> Helper function to remap async functions to generators

See our website [@babel/helper-remap-async-to-generator](https://babeljs.io/docs/en/babel-helper-remap-async-to-generator) for more information.

## Install

Using npm:

```sh
npm install --save @babel/helper-remap-async-to-generator
```

or using yarn:

```sh
yarn add @babel/helper-remap-async-to-generator
```
