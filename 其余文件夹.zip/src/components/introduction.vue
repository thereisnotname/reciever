<template>
  <div class="body">
    <div class="main_nav">
      <ul>
        <li><router-link to="/about_">首页</router-link></li>
        <li><router-link to="/about_us">关于我们</router-link></li>
        <li><router-link to="/introduction">产品介绍</router-link></li>
      </ul>
    </div>
    <section class="text_box">
      <p>hhhh<br />zi</p>
    </section>
    <div class="square">
      <ul>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
      </ul>
    </div>
    <div class="circle">
      <ul>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
      </ul>
    </div>
  </div>
</template>

<script lang="ts">
</script>


<style scoped>
* {
  margin: 0;
  padding: 0;
  list-style-type: none;
}

.body {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  background: linear-gradient(118deg, #7188c0, #a9c1ed);
  overflow: hidden;
  position: absolute;
  width: 100%;
  height: 100%;
  z-index: 5;
}

.square ul li {
  position: absolute;
  border: 1px solid #fff;
  width: 30px;
  height: 30px;
  list-style: none;
  opacity: 0;
  background-color: #fff;
}

.circle ul li {
  position: absolute;
  border: 1px solid #fff;
  width: 30px;
  height: 30px;
  list-style: none;
  opacity: 0;
  background-color: #fff;
}

.square li {
  top: 40vh;
  left: 60vw;
  animation: square 10s linear infinite;
}

.square li:nth-child(2) {
  top: 80vh;
  left: 10vw;
  animation-delay: 2s;
}

.square li:nth-child(3) {
  top: 80vh;
  left: 85vw;
  animation-delay: 4s;
}

.square li:nth-child(4) {
  top: 10vh;
  left: 15vw;
  animation-delay: 3s;
}

.square li:nth-child(5) {
  top: 16vh;
  left: 91vw;
  animation-delay: 5s;
}

.circle li {
  bottom: 0;
  left: 15px;
  animation: circle 10s linear infinite;
}

.circle li:nth-child(2) {
  left: 35vw;
  animation-delay: 3s;
}

.circle li:nth-child(3) {
  left: 45vw;
  animation-delay: 4s;
}

.circle li:nth-child(4) {
  left: 55vw;
  animation-delay: 5s;
}

.circle li:nth-child(5) {
  left: 65vw;
  animation-delay: 8s;
}

.circle li:nth-child(2) {
  left: 75v;
  animation-delay: 2s;
}

@keyframes square {
  0% {
    transform: scale(0) rotateY(0deg);
    opacity: 1;
  }
  100% {
    transform: scale(5) rotateY(1000deg);
    opacity: 0;
  }
}

@keyframes circle {
  0% {
    transform: scale(0) rotateY(0deg);
    opacity: 1;
    bottom: 0;
    border-radius: 0;
  }
  100% {
    transform: scale(5) rotateY(1000deg);
    opacity: 0;
    bottom: 90vh;
    border-radius: 50%;
  }
}

.container {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  width: 270px;
  height: 600px;
  /* border: 1px dashed #fff; */
  perspective: 1000px;
  position: relative;
}

.card-box {
  position: absolute;
  width: 100%;
  height: 100%;
  transform-style: preserve-3d;
  transform: rotateY(0) translateZ(-700px);
  animation: cardRotate 10s cubic-bezier(0.77, 0, 0.175, 1) infinite;
}

.card {
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  bottom: 0;
  width: 270px;
  height: 600px;
  display: flex;
  justify-content: center;
  align-items: center;
  -webkit-box-reflect: below 15px -webkit-linear-gradient(transparent 50%, rgba(255, 255, 255, 0.3));
}

.card img {
  width: 100%;
  height: 100%;
}

.card:nth-child(1) {
  transform: rotateY(0) translateZ(700px);
}

.card:nth-child(2) {
  transform: rotateY(90deg) translateZ(700px);
}

.card:nth-child(3) {
  transform: rotateY(180deg) translateZ(700px);
}

.card:nth-child(4) {
  transform: rotateY(270deg) translateZ(700px);
}

@keyframes cardRotate {
  0%,
  20% {
    transform: translateZ(-700px) rotateY(0);
  }
  40% {
    transform: translateZ(-700px) rotateY(-90deg);
  }
  60% {
    transform: translateZ(-700px) rotateY(-180deg);
  }
  80% {
    transform: translateZ(-700px) rotateY(-270deg);
  }
  100% {
    transform: translateZ(-700px) rotateY(-360deg);
  }
}

.body .main_nav {
  z-index: 7;
}

.main_nav {
  height: 70px;
  width: 100%;
  background-color: #fafafa;
  position: absolute;
  z-index: 6;
}

.main_nav ul li:nth-child(1) {
  position: absolute;
  right: 400px;
}

.main_nav ul li:nth-child(2) {
  position: absolute;
  right: 310px;
}

.main_nav ul li:nth-child(3) {
  position: absolute;
  right: 200px;
}
.main_nav ul li {
  height: auto;
  width: 100px;
  font-size: 20px;
  line-height: 70px;
  text-align: center;
}

.main_nav ul li:hover{
  border-top: 4px solid #a9c1ed;
}
.text_box {
  position: absolute;
  left: 50%;
  top: 55%;
  transform: translate(-50%, -50%);
  z-index: 8;
  width: 1000px;
  height: 690px;
  background-color: rgba(255, 255, 255, 0.5);
  border-radius: 2%;
}

</style>
