import { createApp } from 'vue'
import App from './App.vue'
import { createRouter, createWebHashHistory } from 'vue-router'
import Home from './components/home.vue'
import About_us from './components/about_us.vue'
import world from './components/introduction.vue'


const routes = [{
    path: '/about_',
    component: Home
},
{
    path: '/about_us',
    component: About_us
},
{
    path: '/introduction',
    component: world
},
]


const router = createRouter({
    history: createWebHashHistory(),
    routes,
})

const app = createApp(App).use(router);
app.mount('#app')
