<!-- Use preprocessors via the lang attribute! e.g. <template lang="pug"> -->
//  在vue3的终端输入npm run serve
<template>
  <div class="body">
    <div class="main_nav">
      <ul>
        <li><router-link to="/about_">首页</router-link></li>
        <li><router-link to="/about_us">关于我们</router-link></li>
        <li><router-link to="/HelloWorld">产品介绍</router-link></li>
      </ul>
    </div>
    <div class="square">
      <ul>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
      </ul>
    </div>
    <div class="circle">
      <ul>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
      </ul>
    </div>
    <div class="container">
      <div class="card-box">
        <div class="card">
          <img src="./img/1.jpg" alt="" />
        </div>
        <div class="card">
          <img src="./img/2.jpg" alt="" />
        </div>
        <div class="card">
          <img src="./img/3.jpg" alt="" />
        </div>
        <div class="card">
          <img src="./img/4.jpg" alt="" />
        </div>
      </div>
    </div>
  </div>
   <router-view></router-view>
</template>

<script>

</script>

<style>
@import "./decoration.css";
</style>
